import { SITE, HERO_FACTS, ARTICLES, SCRIPTURES, TIMELINE, TRIVIA, RANKS, HONORIFICS } from "./content.js";

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const STORE = { name: "ark.viewer.name", title: "ark.viewer.honorific" };

const cfgText = (node, fallback) => {
  if (!node) return fallback;
  const raw = node.evaluateItem !== undefined ? node.evaluateItem : node;
  return typeof raw === "string" && raw.trim() ? raw.trim() : fallback;
};
const CFG = (typeof root !== "undefined" && root && root.arkSiteConfig) || {};
const HONORIFIC_OPTIONS = HONORIFICS;
const DEFAULT_HONORIFIC = cfgText(CFG.defaultHonorific, HONORIFICS[0]);

function arkSvg() {
  return `
<svg id="arkArt" viewBox="0 0 400 300" role="img" aria-label="A stylised rendering of the ark of the covenant: a gold chest with rings and staves, a mercy seat above, and two cherubim with outstretched wings.">
  <defs>
    <radialGradient id="glow" cx="50%" cy="44%" r="66%">
      <stop offset="0%" stop-color="#4a3a9e" stop-opacity="0.8"/>
      <stop offset="30%" stop-color="#3a2a86" stop-opacity="0.5"/>
      <stop offset="62%" stop-color="#2a1160" stop-opacity="0.22"/>
      <stop offset="100%" stop-color="#05040c" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="horizon" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#5b6bd6" stop-opacity="0"/>
      <stop offset="50%" stop-color="#8b9cff" stop-opacity="0.55"/>
      <stop offset="100%" stop-color="#5b6bd6" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="metal" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#e6e3f5"/>
      <stop offset="34%" stop-color="#b3abd9"/>
      <stop offset="68%" stop-color="#6f60b0"/>
      <stop offset="100%" stop-color="#392478"/>
    </linearGradient>
    <linearGradient id="metalTop" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#a49cce"/>
      <stop offset="46%" stop-color="#f4f3fd"/>
      <stop offset="100%" stop-color="#a49cce"/>
    </linearGradient>
    <linearGradient id="seat" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#fbfaff"/>
      <stop offset="52%" stop-color="#cdc8e6"/>
      <stop offset="100%" stop-color="#7d71ba"/>
    </linearGradient>
    <linearGradient id="wing" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0%" stop-color="#5a4ba4" stop-opacity="0.95"/>
      <stop offset="58%" stop-color="#a9a3da" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#eeeefb" stop-opacity="0.8"/>
    </linearGradient>
    <linearGradient id="pole" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#c8c3e0"/>
      <stop offset="50%" stop-color="#7d74ab"/>
      <stop offset="100%" stop-color="#3a2c68"/>
    </linearGradient>
  </defs>

  <ellipse cx="200" cy="146" rx="200" ry="152" fill="url(#glow)"/>
  <ellipse cx="200" cy="236" rx="126" ry="11" fill="#02010a" opacity="0.75"/>
  <rect x="34" y="241" width="332" height="1" fill="url(#horizon)"/>

  <g>
    <rect x="18" y="192" width="112" height="9" rx="4.5" fill="url(#pole)"/>
    <rect x="270" y="192" width="112" height="9" rx="4.5" fill="url(#pole)"/>
    <rect x="18" y="200" width="112" height="2.4" rx="1.2" fill="#1b1440" opacity="0.85"/>
    <rect x="270" y="200" width="112" height="2.4" rx="1.2" fill="#1b1440" opacity="0.85"/>
    <circle cx="112" cy="196.5" r="11" fill="none" stroke="url(#metalTop)" stroke-width="4.5"/>
    <circle cx="288" cy="196.5" r="11" fill="none" stroke="url(#metalTop)" stroke-width="4.5"/>
  </g>

  <g>
    <rect x="106" y="158" width="188" height="11" rx="3" fill="url(#metalTop)"/>
    <rect x="106" y="158" width="188" height="3.2" rx="1.6" fill="#efeefb" opacity="0.75"/>
    <rect x="108" y="167" width="184" height="64" fill="url(#metal)"/>
    <rect x="108" y="167" width="184" height="64" fill="none" stroke="#1a1038" stroke-width="1.4" opacity="0.7"/>
    <rect x="122" y="179" width="156" height="42" rx="2" fill="none" stroke="#2b1a55" stroke-width="1" opacity="0.8"/>
    <rect x="136" y="189" width="128" height="23" rx="2" fill="none" stroke="#3b4fc4" stroke-width="0.9" opacity="0.55"/>
    <rect x="108" y="227" width="184" height="5" rx="2.5" fill="#160e33"/>
  </g>

  <g>
    <rect x="118" y="145" width="164" height="14" rx="3" fill="url(#seat)"/>
    <rect x="118" y="145" width="164" height="3" rx="1.5" fill="#f4f3ff" opacity="0.85"/>
    <rect x="118" y="156" width="164" height="2.4" fill="#2a1755" opacity="0.8"/>
  </g>

  <g class="cherubim">
    <g>
      <path d="M151 145 C128 138 112 118 104 90 C122 106 138 114 152 120 Z" fill="url(#wing)" stroke="#3b2f78" stroke-width="1" opacity="0.92"/>
      <path d="M150 145 C168 137 179 122 184 104 C173 116 162 124 151 128 Z" fill="url(#wing)" stroke="#3b2f78" stroke-width="1" opacity="0.8"/>
      <path d="M150 145 L139 145 L143.5 119 L150 111 L156.5 119 L161 145 Z" fill="url(#metalTop)" stroke="#2b1a55" stroke-width="1.1"/>
      <circle cx="150" cy="104" r="6.6" fill="#dcd9ee" stroke="#2b1a55" stroke-width="1.1"/>
      <path d="M144 106 q6 5 12 0" fill="none" stroke="#3a2c68" stroke-width="0.9" opacity="0.8"/>
    </g>
    <g>
      <path d="M249 145 C272 138 288 118 296 90 C278 106 262 114 248 120 Z" fill="url(#wing)" stroke="#3b2f78" stroke-width="1" opacity="0.92"/>
      <path d="M250 145 C232 137 221 122 216 104 C227 116 238 124 249 128 Z" fill="url(#wing)" stroke="#3b2f78" stroke-width="1" opacity="0.8"/>
      <path d="M250 145 L261 145 L256.5 119 L250 111 L243.5 119 L239 145 Z" fill="url(#metalTop)" stroke="#2b1a55" stroke-width="1.1"/>
      <circle cx="250" cy="104" r="6.6" fill="#dcd9ee" stroke="#2b1a55" stroke-width="1.1"/>
      <path d="M244 106 q6 5 12 0" fill="none" stroke="#3a2c68" stroke-width="0.9" opacity="0.8"/>
    </g>
  </g>

  <g opacity="0.55">
    <path d="M200 40 L204 52 L216 56 L204 60 L200 72 L196 60 L184 56 L196 52 Z" fill="#9aa6ff"/>
  </g>
</svg>`;
}

function renderHero() {
  $("#arkArtCtn").innerHTML = arkSvg();
  $("#factRow").innerHTML = HERO_FACTS.map(
    (f) => `<div class="fact"><span class="fact-k">${esc(f.k)}</span><span class="fact-v">${esc(f.v)}</span><span class="fact-r">${esc(f.r)}</span></div>`
  ).join("");
}

function renderArticles() {
  $("#articleGrid").innerHTML = ARTICLES.map(
    (a) => `
    <article class="card" data-id="${esc(a.id)}" tabindex="0" role="button" aria-label="Read ${esc(a.title)}">
      <div class="card-no">${esc(a.no)}</div>
      <h3 class="card-title">${esc(a.title)}</h3>
      <p class="card-sub">${esc(a.subtitle)}</p>
      <div class="chips">${a.refs.map((r) => `<span class="chip">${esc(r)}</span>`).join("")}</div>
      <span class="card-cta">Read the article</span>
    </article>`
  ).join("");
}

function blockHtml(b) {
  if (b.t === "p") return `<p>${b.x}</p>`;
  if (b.t === "h") return `<h4 class="blk-h">${esc(b.x)}</h4>`;
  if (b.t === "q") return `<blockquote><p>${b.x}</p><cite>${esc(b.ref || "")}</cite></blockquote>`;
  if (b.t === "note") return `<aside class="blk-note">${b.x}</aside>`;
  if (b.t === "list") return `<ul class="blk-list">${b.items.map((i) => `<li>${i}</li>`).join("")}</ul>`;
  if (b.t === "tiers")
    return `<div class="tiers">${b.items
      .map(
        (i) => `<div class="tier">
          <div class="tier-head"><span class="tier-name">${esc(i.tier)}</span><span class="tier-badge">${esc(i.badge)}</span></div>
          <h5>${esc(i.title)}</h5><p>${i.x}</p></div>`
      )
      .join("")}</div>`;
  return "";
}

let lastFocus = null;
function openArticle(id) {
  const a = ARTICLES.find((x) => x.id === id);
  if (!a) return;
  lastFocus = document.activeElement;
  $("#readerBody").innerHTML = `
    <div class="reader-mark">Article ${esc(a.no)}</div>
    <h2 class="reader-title">${esc(a.title)}</h2>
    <p class="reader-sub">${esc(a.subtitle)}</p>
    <div class="chips">${a.refs.map((r) => `<span class="chip">${esc(r)}</span>`).join("")}</div>
    <div class="reader-text">${a.body.map(blockHtml).join("")}</div>
    <p class="reader-end">— end of article ${esc(a.no)} —</p>`;
  $("#reader").hidden = false;
  document.body.classList.add("locked");
  $("#reader").scrollTop = 0;
  $("#readerClose").focus();
}
function closeArticle() {
  $("#reader").hidden = true;
  document.body.classList.remove("locked");
  if (lastFocus) lastFocus.focus();
}

function renderScriptures(filter = "") {
  const q = filter.trim().toLowerCase();
  const hits = SCRIPTURES.filter(
    (s) => !q || s.ref.toLowerCase().includes(q) || s.text.toLowerCase().includes(q) || s.tags.includes(q) || s.section.toLowerCase().includes(q)
  );
  $("#scriptCount").textContent = q
    ? `${hits.length} of ${SCRIPTURES.length} passages match "${filter.trim()}"`
    : `${SCRIPTURES.length} passages indexed`;
  if (!hits.length) {
    $("#scriptureList").innerHTML = `<p class="empty">No passage found. Try a word such as <em>cherubim</em>, <em>mercy</em>, <em>gold</em>, or a reference such as <em>1 Samuel 5</em>.</p>`;
    return;
  }
  const groups = [];
  for (const s of hits) {
    let g = groups.find((x) => x.name === s.section);
    if (!g) groups.push((g = { name: s.section, items: [] }));
    g.items.push(s);
  }
  $("#scriptureList").innerHTML = groups
    .map(
      (g) => `<section class="scr-group"><h4 class="scr-group-h">${esc(g.name)}</h4>${g.items
        .map(
          (s) => `<details class="verse"><summary><span class="v-ref">${esc(s.ref)}</span><span class="v-open">open</span></summary>
            <p class="v-text">${esc(s.text)}</p></details>`
        )
        .join("")}</section>`
    )
    .join("");
}

function renderTimeline() {
  $("#timelineList").innerHTML = TIMELINE.map(
    (t) => `<li class="tl-item">
      <div class="tl-dot" aria-hidden="true"></div>
      <div class="tl-card">
        <span class="tl-when">${esc(t.when)}</span>
        <h4>${esc(t.title)}</h4>
        <p>${esc(t.text)}</p>
        <span class="tl-ref">${esc(t.ref)}</span>
      </div></li>`
  ).join("");
}

function honorificLabel(title, name) {
  if (!title || title.startsWith("No title")) return name;
  return `${title} ${name}`;
}

const quiz = { order: [], i: 0, score: 0, answered: false, missed: [] };

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function startQuiz() {
  quiz.order = shuffle(TRIVIA);
  quiz.i = 0;
  quiz.score = 0;
  quiz.missed = [];
  quiz.answered = false;
  $("#quizIntro").hidden = true;
  $("#quizResult").hidden = true;
  $("#quizPlay").hidden = false;
  paintQuestion();
}

function alignToStart(el) {
  if (!el || el.hidden) return;
  requestAnimationFrame(() => {
    const pad = scrollPadding();
    const top = el.getBoundingClientRect().top;
    if (top < pad - 6 || top > pad + 90) {
      window.scrollBy({ top: top - pad, behavior: "smooth" });
    }
  });
}

function focusQuietly(el) {
  if (el && typeof el.focus === "function") {
    try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); }
  }
}

function scrollPadding() {
  return parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0;
}

function revealQuizControls() {
  const next = $("#quizNext");
  const head = $("#quizQ");
  if (!next || next.hidden || !head) return;
  const over = next.getBoundingClientRect().bottom + 16 - window.innerHeight;
  if (over <= 0) return;
  const keepHeadVisible = Math.max(0, head.getBoundingClientRect().top - scrollPadding() - 12);
  const delta = Math.min(over, keepHeadVisible);
  if (delta > 8) window.scrollBy({ top: delta, behavior: "smooth" });
}

function paintQuestion() {
  const q = quiz.order[quiz.i];
  const name = localStorage.getItem(STORE.name) || "";
  const title = localStorage.getItem(STORE.title) || "";
  $("#quizProgress").style.width = `${(quiz.i / quiz.order.length) * 100}%`;
  $("#quizCount").textContent = `Question ${quiz.i + 1} of ${quiz.order.length}`;
  $("#quizScore").textContent = `Score: ${quiz.score}`;
  $("#quizWho").textContent = name ? `In the name of ${honorificLabel(title, name)}` : "";
  $("#quizQ").textContent = q.q;
  const letters = ["A", "B", "C", "D"];
  $("#quizOpts").innerHTML = q.a
    .map((opt, idx) => `<button class="opt" data-i="${idx}"><span class="opt-k">${letters[idx]}</span><span class="opt-v">${esc(opt)}</span></button>`)
    .join("");
  $("#quizWhy").hidden = true;
  $("#quizWhy").innerHTML = "";
  $("#quizNext").hidden = true;
  quiz.answered = false;
  if (quiz.i > 0) alignToStart($("#quizPlay"));
  focusQuietly($("#quizQ"));
}

function answer(idx) {
  if (quiz.answered) return;
  quiz.answered = true;
  const q = quiz.order[quiz.i];
  const btns = $$("#quizOpts .opt");
  btns.forEach((b, i) => {
    b.disabled = true;
    if (i === q.correct) b.classList.add("is-correct");
    else if (i === idx) b.classList.add("is-wrong");
  });
  if (idx === q.correct) quiz.score++;
  else quiz.missed.push(q);
  $("#quizScore").textContent = `Score: ${quiz.score}`;
  const why = $("#quizWhy");
  why.innerHTML = `<p class="why-verdict">${idx === q.correct ? "Correct." : "Not so — the answer is " + esc(q.a[q.correct]) + "."}</p>
    <p class="why-text">${esc(q.why)}</p><span class="why-ref">${esc(q.ref)}</span>`;
  why.hidden = false;
  const next = $("#quizNext");
  next.textContent = quiz.i === quiz.order.length - 1 ? "See the result" : "Next question";
  next.hidden = false;
  requestAnimationFrame(revealQuizControls);
  focusQuietly(next);
}

function finishQuiz() {
  const total = quiz.order.length;
  const frac = quiz.score / total;
  const rank = RANKS.find((r) => frac >= r.min);
  const name = localStorage.getItem(STORE.name) || "";
  const title = localStorage.getItem(STORE.title) || "";
  $("#quizPlay").hidden = true;
  $("#quizIntro").hidden = true;
  $("#quizResult").hidden = false;
  $("#quizResult").innerHTML = `
    <div class="result-mark">Result</div>
    <h3 class="result-who">${esc(honorificLabel(title, name))}</h3>
    <p class="result-score">${quiz.score} <span>of ${total}</span></p>
    <p class="result-rank">${esc(rank.name)}</p>
    <p class="result-note">${esc(rank.note)}</p>
    ${
      quiz.missed.length
        ? `<div class="result-missed"><h4>Worth reading again</h4><ul>${quiz.missed
            .map((m) => `<li><span>${esc(m.q)}</span><em>${esc(m.ref)}</em></li>`)
            .join("")}</ul></div>`
        : `<p class="result-perfect">A clean sweep of the testimony.</p>`
    }
    <div class="result-actions">
      <button class="btn btn-primary" id="quizAgain">Test again</button>
      <a class="btn btn-ghost" href="#articles">Return to the articles</a>
    </div>`;
  $("#quizAgain").addEventListener("click", () => {
    $("#quizResult").hidden = true;
    $("#quizIntro").hidden = false;
  });
  alignToStart($("#quizResult"));
}

function paintGate() {
  const name = localStorage.getItem(STORE.name) || "";
  const title = localStorage.getItem(STORE.title) || "";
  if (name) {
    $("#gate").hidden = true;
    $("#quizArea").hidden = false;
    $("#greetWho").textContent = honorificLabel(title, name);
    $("#quizIntro").hidden = false;
    $("#quizPlay").hidden = true;
    $("#quizResult").hidden = true;
  } else {
    $("#gate").hidden = false;
    $("#quizArea").hidden = true;
    $("#viewerName").value = "";
  }
}

function applyStyle() {
  $("#countArticles").textContent = ARTICLES.length;
  $("#countScriptures").textContent = SCRIPTURES.length;
  $("#countTrivia").textContent = TRIVIA.length;
  $("#quizIntroCount").textContent = TRIVIA.length;
  $("#footArticles").textContent = ARTICLES.length;
  $("#footScriptures").textContent = SCRIPTURES.length;
  $("#footTrivia").textContent = TRIVIA.length;
}

function initNavHighlight() {
  const links = $$(".nav-link");
  const targets = links.map((l) => $(l.getAttribute("href"))).filter(Boolean);
  const update = () => {
    const y = window.innerHeight * 0.32;
    let current = targets[0];
    for (const t of targets) {
      if (t.getBoundingClientRect().top <= y) current = t;
    }
    links.forEach((l) => l.classList.toggle("active", current && l.getAttribute("href") === "#" + current.id));
  };
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update);
  update();
}

function initReveal() {
  const items = $$(".reveal");
  const check = () => {
    const y = window.innerHeight * 0.92;
    items.forEach((el) => {
      if (el.getBoundingClientRect().top < y) el.classList.add("in");
    });
  };
  window.addEventListener("scroll", check, { passive: true });
  window.addEventListener("resize", check);
  check();
  setTimeout(check, 400);
}

function initProgress() {
  const bar = $("#progressBar");
  const update = () => {
    const h = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.transform = `scaleX(${h > 0 ? Math.min(1, window.scrollY / h) : 0})`;
  };
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update);
  update();
}

function init() {
  renderHero();
  renderArticles();
  renderScriptures("");
  renderTimeline();
  applyStyle();
  $("#heroSub").textContent = cfgText(CFG.subtitle, SITE.subtitle);
  $("#heroDedication").textContent = cfgText(CFG.dedication, SITE.dedication);
  $("#viewerTitle").innerHTML = HONORIFIC_OPTIONS.map((h) => `<option value="${esc(h)}">${esc(h)}</option>`).join("");
  $("#viewerTitle").value = DEFAULT_HONORIFIC;
  paintGate();

  $("#articleGrid").addEventListener("click", (e) => {
    const card = e.target.closest(".card");
    if (card) openArticle(card.dataset.id);
  });
  $("#articleGrid").addEventListener("keydown", (e) => {
    const card = e.target.closest(".card");
    if (card && (e.key === "Enter" || e.key === " ")) {
      e.preventDefault();
      openArticle(card.dataset.id);
    }
  });
  $("#readerClose").addEventListener("click", closeArticle);
  $("#reader").addEventListener("click", (e) => {
    if (e.target.id === "reader") closeArticle();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !$("#reader").hidden) closeArticle();
  });

  $("#scriptSearch").addEventListener("input", (e) => renderScriptures(e.target.value));

  $("#gateForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const raw = $("#viewerName").value.trim().slice(0, 40);
    if (!raw) {
      $("#gateError").textContent = "The archive asks for a name before the trivia is opened.";
      $("#viewerName").focus();
      return;
    }
    $("#gateError").textContent = "";
    localStorage.setItem(STORE.name, raw);
    localStorage.setItem(STORE.title, $("#viewerTitle").value);
    paintGate();
    $("#quizArea").scrollIntoView({ block: "start", behavior: "smooth" });
  });
  $("#changeName").addEventListener("click", () => {
    localStorage.removeItem(STORE.name);
    localStorage.removeItem(STORE.title);
    $("#quizPlay").hidden = true;
    $("#quizResult").hidden = true;
    paintGate();
    $("#viewerName").focus();
  });
  $("#quizStart").addEventListener("click", startQuiz);
  $("#quizOpts").addEventListener("click", (e) => {
    const b = e.target.closest(".opt");
    if (b && !b.disabled) answer(Number(b.dataset.i));
  });
  $("#quizNext").addEventListener("click", () => {
    if (quiz.i === quiz.order.length - 1) finishQuiz();
    else {
      quiz.i++;
      paintQuestion();
    }
  });

  initNavHighlight();
  initReveal();
  initProgress();
  const year = $("#year");
  if (year) year.textContent = new Date().getFullYear();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
else init();
